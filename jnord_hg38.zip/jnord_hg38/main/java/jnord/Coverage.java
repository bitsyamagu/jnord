package jnord;

public class Coverage {
    String chr;
    int pos;
    int coverage;
}
