package jnord;

public interface Detector {
    public int check(double score, double median);
};

