package jnord;

public class Exon extends RODImpl{
    public Exon(String chr, int start, int end){
        super(chr, start, end);
    }
}
